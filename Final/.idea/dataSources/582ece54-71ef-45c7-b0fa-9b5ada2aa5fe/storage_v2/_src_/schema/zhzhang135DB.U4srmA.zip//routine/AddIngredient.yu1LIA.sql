CREATE PROCEDURE AddIngredient(IN addIngredientName VARCHAR(30), IN setIsVegan TINYINT, IN setIsSeasoning TINYINT,
                               IN weight            INT, IN energy INT)
  BEGIN
    IF addIngredientName NOT IN (SELECT ingredientName
                                 FROM Ingredient)
    THEN
      INSERT INTO Ingredient
      VALUES (addIngredientName, weight, energy, setIsVegan, setIsSeasoning, 				NULL);
    ELSE
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Ingredient Already exists!";
    END IF;
  END;

