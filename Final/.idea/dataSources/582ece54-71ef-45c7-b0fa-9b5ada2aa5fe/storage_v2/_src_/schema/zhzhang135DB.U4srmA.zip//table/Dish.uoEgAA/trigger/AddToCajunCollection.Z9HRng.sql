CREATE TRIGGER AddToCajunCollection
  AFTER INSERT
  ON Dish
  FOR EACH ROW
  BEGIN
		IF (NEW.styleName) = "Cajun" THEN
			INSERT INTO CajunCollection(dishName, instructionsLink, cookingTime)
				VALUES (NEW.dishName, NEW.instructionsLink, NEW.cookingTime);
		END IF;
	END;

