CREATE TRIGGER LogDishUpdates
  AFTER UPDATE
  ON Dish
  FOR EACH ROW
  BEGIN
		IF (NEW.styleName <> OLD.styleName) THEN
			INSERT IGNORE INTO DishUpdates
				VALUES (NEW.dishName, OLD.styleName, NEW.styleName, CURRENT_USER(), NOW());
		END IF;
	END;

