CREATE VIEW HongKongMarketBargains AS
  SELECT
    `stuffList`.`stuffName`     AS `stuffName`,
    `stuffList`.`price`         AS `price`,
    `stuffList`.`stuffCategory` AS `stuffCategory`
  FROM (SELECT
          `zhzhang135DB`.`SellsIngredient`.`ingredientName` AS `stuffName`,
          `zhzhang135DB`.`SellsIngredient`.`price`          AS `price`,
          `zhzhang135DB`.`SellsIngredient`.`storeName`      AS `storeName`,
          'Ingredient'                                      AS `stuffCategory`
        FROM `zhzhang135DB`.`SellsIngredient`
        UNION SELECT
                `zhzhang135DB`.`SellsKitchenWare`.`kitchenWareName` AS `stuffName`,
                `zhzhang135DB`.`SellsKitchenWare`.`price`           AS `price`,
                `zhzhang135DB`.`SellsKitchenWare`.`storeName`       AS `storeName`,
                'Kitchen Ware'                                      AS `stuffCategory`
              FROM `zhzhang135DB`.`SellsKitchenWare`) `stuffList`
  WHERE ((`stuffList`.`price` <= 25) AND (`stuffList`.`storeName` = 'Hong Kong Market'));

