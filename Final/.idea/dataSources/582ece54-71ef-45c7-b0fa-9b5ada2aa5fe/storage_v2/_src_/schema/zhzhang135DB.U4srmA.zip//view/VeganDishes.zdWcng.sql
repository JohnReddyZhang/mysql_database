CREATE VIEW VeganDishes AS
  SELECT `zhzhang135DB`.`Dish`.`dishName` AS `dishName`
  FROM ((`zhzhang135DB`.`Dish`
    JOIN `zhzhang135DB`.`UseIngredient`
      ON ((`zhzhang135DB`.`Dish`.`ID` = `zhzhang135DB`.`UseIngredient`.`dishID`))) JOIN `zhzhang135DB`.`Ingredient`
      ON ((`zhzhang135DB`.`UseIngredient`.`ingredientName` = `zhzhang135DB`.`Ingredient`.`ingredientName`)))
  GROUP BY `zhzhang135DB`.`Dish`.`dishName`
  HAVING (sum(`zhzhang135DB`.`Ingredient`.`isVegan`) = count(`zhzhang135DB`.`Ingredient`.`isVegan`));

