CREATE PROCEDURE PriceMoreThan(IN forPrice FLOAT)
  BEGIN
	SELECT Dish.dishName, Round(SUM(price),2) AS price
	FROM Dish
	INNER JOIN UseIngredient
	ON UseIngredient.dishID = Dish.ID
	INNER JOIN SellsIngredient
	USING (ingredientName)
	GROUP BY Dish.dishName
	HAVING SUM(price) > forPrice;
END;

