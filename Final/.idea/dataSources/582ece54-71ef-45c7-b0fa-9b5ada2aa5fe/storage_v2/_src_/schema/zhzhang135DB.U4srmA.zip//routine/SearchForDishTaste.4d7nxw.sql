CREATE PROCEDURE SearchForDishTaste(IN findTaste VARCHAR(30), IN findStrength VARCHAR(30))
  BEGIN
	IF findTaste NOT IN (SELECT flavorName FROM Flavor) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not FOUND!';
	ELSE
		IF findStrength IS NULL THEN
			SELECT d.dishName, t.flavorName, t.strength
			FROM DishTaste t
			INNER JOIN Dish d
			ON d.ID = t.dishID
			WHERE t.flavorName = findTaste;
		ELSE
			SELECT d.dishName, t.flavorName, t.strength
			FROM DishTaste t
			INNER JOIN Dish d
			ON d.ID = t.dishID
			WHERE t.flavorName = findTaste
			AND t.strength = findStrength;
		END IF;
	END IF;
END;

