CREATE PROCEDURE usesIngredient(IN useIngredientName VARCHAR(30))
  BEGIN
	IF useIngredientName NOT IN (SELECT ingredientName FROM Ingredient) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not FOUND!';
	ELSE
		SELECT DISTINCT d.dishName Dish, u.ingredientName Ingredient
		FROM Dish d
		INNER JOIN UseIngredient u
		ON d.ID = u.dishID
		WHERE u.ingredientName = useIngredientName;
	END IF;
END;
